const board = document.getElementById('board');
const rollBtn = document.getElementById('rollBtn');
const diceResult = document.getElementById('diceResult');
const turnIndicator = document.getElementById('turnIndicator');
const message = document.getElementById('message');
const diceSound = document.getElementById('diceSound');
const mariachiSound = document.getElementById('mariachiSound');
const confettiContainer = document.getElementById('confetti');

let playerPositions = [0, 0];
let currentPlayer = 0;

// Serpientes y escaleras
const snakes = {16:6, 48:30, 62:19, 88:24};
const ladders = {3:22, 5:8, 11:26, 20:29};

// Crear tablero
for(let i=100;i>=1;i--){
  const cell = document.createElement('div');
  cell.classList.add('cell');
  cell.id = 'cell'+i;
  cell.textContent = i;
  board.appendChild(cell);
}

function updateBoard(){
  document.querySelectorAll('.player1, .player2').forEach(e=>e.remove());
  playerPositions.forEach((pos, idx)=>{
    if(pos>0){
      const el = document.createElement('div');
      el.classList.add(idx===0?'player1':'player2');
      const cell = document.getElementById('cell'+pos);
      cell.appendChild(el);
    }
  });
}

function launchConfetti(){
  for(let i=0;i<200;i++){
    const c = document.createElement('div');
    c.style.position='absolute';
    c.style.width='8px';
    c.style.height='8px';
    c.style.backgroundColor=`hsl(${Math.random()*360},100%,50%)`;
    c.style.top='0px';
    c.style.left=Math.random()*window.innerWidth+'px';
    c.style.opacity=Math.random();
    c.style.transform=`rotate(${Math.random()*360}deg)`;
    confettiContainer.appendChild(c);
    let fall = setInterval(()=>{
      let top = parseFloat(c.style.top);
      if(top>window.innerHeight){ c.remove(); clearInterval(fall);}
      else c.style.top = top + (Math.random()*5 + 2) + 'px';
    },20);
  }
}

rollBtn.addEventListener('click', ()=>{
  diceSound.play();
  let roll = Math.floor(Math.random()*6)+1;
  diceResult.textContent = 'Dado: '+roll;
  playerPositions[currentPlayer] += roll;

  // Revisar serpiente o escalera
  if(playerPositions[currentPlayer] in snakes){
    message.textContent = '¡Oh no! Caíste en la cabeza de la serpiente, bajas.';
    playerPositions[currentPlayer] = snakes[playerPositions[currentPlayer]];
  } else if(playerPositions[currentPlayer] in ladders){
    message.textContent = '¡Súbete por la escalera!';
    playerPositions[currentPlayer] = ladders[playerPositions[currentPlayer]];
  } else {
    message.textContent = '';
  }

  if(playerPositions[currentPlayer]>=100){
    playerPositions[currentPlayer]=100;
    updateBoard();
    turnIndicator.textContent = '¡Jugador '+(currentPlayer+1)+' gana!';
    mariachiSound.play();
    launchConfetti();
    rollBtn.disabled=true;
    return;
  }

  updateBoard();
  currentPlayer = currentPlayer===0?1:0;
  turnIndicator.textContent = 'Turno: Jugador '+(currentPlayer===0?'A':'B');
});

